package com.generation.lojagames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojagamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojagamesApplication.class, args);
	}

}
